Adlanta is a beautiful and round cornered font with two weights, Light and regular.
Adlanta is 100% free for personal and commercial uses.